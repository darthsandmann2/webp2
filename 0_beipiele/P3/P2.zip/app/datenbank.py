# coding: utf-8

import os
import os.path
import codecs
import json

class database(object):
	def __init__(self):
		self.data_o = {}
		self.lesen_inhalt_db()
		
	def erzeugen_json_db(self, data_opl):
		id_s = self.naechste_db()
		file_o = codecs.open(os.path.join('data', id_s+'.data'), 'w', 'utf-8')
		file_o.write(json.dumps(data_opl, indent=3, ensure_ascii=True))
		file_o.close()
		self.data_o[id_s] = data_opl
		return id_s
		
	def lesen_json_db(self, id_spl = None):
		data_o = None
		if id_spl == None:
			data_o = self.data_o
		else:
			if id_spl in self.data_o:
				data_o = self.data_o[id_spl]
		return data_o
		
	def update_json_db(self, id_spl, data_opl):
		status_b = False
		if id_spl in self.data_o:
			file_o = codecs.open(os.path.join('data', id_spl+'.data'), 'w', 'utf-8')
			file_o.write(json.dumps(data_opl, indent=3, ensure_ascii=True))
			file_o.close
			self.data_o[id_spl] = data_opl
			status_b = True
		return status_b
		
	def loesche_json_db(self, id_spl):
		status_b = False
		if id_spl in self.data_o:
			os.remove(os.path.join('data', id_spl+'.data'))
			del self.data_o[id_spl]
			status_b = True
		return status_b
		
	def inhalt_db(self):
		return {
			'Vorname': '',
			'Nachname': '',
			'Gaeste': '',
			'Studiengang': '',
			'Betreuer': '',
			'Passwort': '',
			'Matrikelnummer': ''
			}
	
	def lesen_inhalt_db(self):
		files_a = os.listdir('data')
		for fileName_s in files_a:
			if fileName_s.endswith('.data') and fileName_s != 'maximal.data':
				file_o = codecs.open(os.path.join('data', fileName_s), 'rU', 'utf-8')
				content_s = file_o.read()
				id_s = fileName_s[:-4]
				self.data_o[id_s] = json.loads(content_s)
				
	def naechste_db(self):
		file_o = open(os.path.join('data', 'maximal.data'), 'r+')
		maximal = file_o.read()
		maximal = str(int(maximal)+1)
		file_o.seek(0)
		file_o.write(maximal)
		file_o.close()
		return maximal
# EOF