# coding: utf-8

import cherrypy
from app import datenbank
from app import anzeigen

class programm(object):
	def __init__(self):
		self.datenbank_py = datenbank.database()
		self.anzeigen_py = anzeigen.show()
		
	def index(self):
		return self.erzeugen_anzeige_app()
			
	index.exposed = True
	
	def hinzufuegen_app(self):
		return self.erzeugen_bearbeiten_app()
	
	hinzufuegen_app.exposed = True
	
	def passwort_app(self, id):
		return self.erzeugen_passwort_app(id)
	
	passwort_app.exposed = True
	
	def passwort_loeschen_app(self, id):
		return self.erzeugen_passwort_loeschen_app(id)
	
	passwort_loeschen_app.exposed = True
	
	def bearbeiten_app(self, id_s, pw):
		data_o = self.datenbank_py.lesen_json_db(id_s)
		if pw == data_o['Passwort']:
			return self.erzeugen_bearbeiten_app(id_s)
		elif pw == "" or pw != data_o['Passwort']:
			return self.erzeugen_anzeigen_app()
	bearbeiten_app.exposed = True
	
	def speichern_app(self, **data_opl):
		id_s = data_opl["id_s"]
		data_o = {
			'Vorname': data_opl["Vorname_s"],
			'Nachname': data_opl["Nachname_s"],
			'Gaeste': data_opl["Gaeste_s"],
			'Studiengang': data_opl["Studiengang_s"],
			'Betreuer': data_opl["Betreuer_s"],
			'Passwort': data_opl["Passwort_s"],
			'Matrikelnummer': data_opl["Matrikelnummer_s"]
		}
		if id_s != "None":
			self.datenbank_py.update_json_db(id_s, data_o)
		else:
			id_s = self.datenbank_py.erzeugen_json_db(data_o)
		return self.anzeigen_py.erzeugen_bearbeiten_az(id_s, data_o)
	
	speichern_app.exposed = True
	
	def loeschen_app(self, id_s, pw):
		data_o = self.datenbank_py.lesen_json_db(id_s)
		if pw == data_o['Passwort']:
			self.datenbank_py.loesche_json_db(id_s)
			return self.erzeugen_anzeige_app()
		elif pw =="" or pw!= data_o['Passwort']:
			return self.erzeugen_anzeige_app()
	
	loeschen_app.exposed = True
	
	def fehler_app(self, *arguments, **kwargs):
		msg_s = "Fehler: " + \
			str(arguments) + \
			' ' + \
			str(kwargs)
		raise cherrypy.HTTPError(404, msg_s)
	
	fehler_app.exposed = True
	
	def erzeugen_anzeige_app(self):
		data_o = self.datenbank_py.lesen_json_db()
		return self.anzeigen_py.erzeugen_anzeigen_az(data_o)
		
	def erzeugen_bearbeiten_app(self, id_spl = None):
		if id_spl != None:
			data_o = self.datenbank_py.lesen_json_db(id_spl)
		else:
			data_o = self.datenbank_py.inhalt_db()
		return self.anzeigen_py.erzeugen_bearbeiten_az(id_spl, data_o)
		
	def erzeugen_passwort_app(self, id_spl):
		data_o = self.datenbank_py.lesen_json_db(id_spl)
		return self.anzeigen_py.passwort_az(id_spl, data_o)
		
	def erzeugen_passwort_loeschen_app(self, id_spl):
		data_o = self.datenbank_py.lesen_json_db(id_spl)
		return self.anzeigen_py.passwort_loeschen_az(id_spl, data_o)
			
#EOF